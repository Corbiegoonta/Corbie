import art
request = "yes"
print(art.logo)
while request == "yes":
  

  alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

  
  direction = input("Type 'encode' to encrypt, type 'decode' to decrypt:\n")
  if direction == "encode" or direction == "decode":
    text = input("Type your message:\n").lower()
    shift = int(input("Type the shift number:\n"))
  else:
    print(f'Sorry, "{direction}" is an invalid input. Please try again.')

  def ceasar(algo=direction, text1=text, shift1=shift):  
    #encryption
    if algo == "encode":
      wi = []
      fl = []
      cl = []

      for i in text1:
        if i in alphabet:
          wi.append(alphabet.index(i))
          cl.append(alphabet.index(i))
        else:
          wi.append(i)

      print(wi)
      sl = alphabet
      check = 0
      while check != shift1:
          sl.append(sl[0])
          sl.remove(sl[0])
          check += 1

      for i in wi:
        if i in cl:
          fl.append(sl[i])
        else:
          fl.append(i)
      
      dec1 = ''.join(fl)
      print(f"Your encoded message is {dec1}.")
    elif algo == "decode":
    #decryption
      tl = text1
      nl = []
      cl1 = []

      for i in tl:
        if i in alphabet:
          nl.append(alphabet.index(i))
          cl1.append(alphabet.index(i))
        else:
          nl.append(i)
          
      ac = alphabet
      el = []
      
      for i in range(0, shift1):
        el.insert(0, ac[-1])
        ac.remove(ac[-1])
        ac.insert(0, el[0])

      fel = []
      for i in nl:
        if i in cl1:
          fel.append(ac[i])
        else:
          fel.append(i)

      dec = ''.join(fel)

      print(f"The decoded text is {dec}.")

  ceasar(algo=direction, text1=text, shift1=shift)
  
  b = "q"
  if request == "yes":
    while b == "q":
      b = input("Do you want to use Ceasar's Cipher again?\n")
      if b == "yes":
        request = "yes"
      elif b == "no":
        request = "no"
        print("Thank you for using Ceasar's Cipher.")
      else:
        b = "q"
        print(f"Sorry {b} is an invalid input")
        
  else:
    request == "no"
    print("Thank you for using Ceasar's Cipher.")
  
